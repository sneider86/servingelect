<footer style="background: linear-gradient(90deg, #0356a8, #22a7bf);" class="py-4 bg-light mt-auto">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between small">
            <div style="color:white">Copyright &copy; E.K-Soft -Desarrollo de Software- <?php echo date('Y'); ?></div>
            <div >
                <a style="color:white" href="#">Facebook</a>
                &middot;
                <a style="color:white" href="#">Página Web</a>
            </div>
        </div>
    </div>
</footer>

<script src="<?php echo base_url();?>/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>/js/scripts.js"></script>
<script src="<?php echo base_url();?>/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>/assets/demo/datatables-demo.js"></script>


<script>
    $('#modal-confirma').on('show.bs.modal', function(e){
        $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
    });
</script>

</body>

</html>