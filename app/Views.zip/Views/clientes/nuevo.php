<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <!--<h5 class="mt-4"><?php echo $titulo; ?></h5>-->
            <!--con este php mostramos los errores que se presenten -->
            <?php if (isset($validation)) { ?>
                <div class="alert alert-danger">
                    <?php echo $validation->listErrors(); ?>
                </div>
            <?php } ?>

            <form name="f1" method="POST" action="<?php echo base_url(); ?>/clientes/insertar" autocomplete="off">
                <div class="card shadow-lg border-1 rounded-lg mt-3">
                    <div style="background: linear-gradient(90deg, #6484a5, #22a7bf);">
                        <h3 style="font-weight: bold;font-size:22px;" class="text-center my-2"><?php echo $titulo; ?></h3>
                    </div>
                    <div style="background: linear-gradient(90deg, #b2b8bc, #dbddde);" class="card-body">
                        <div class="form-group col-12">
                            <div class="row">
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Tipo de Documento</label>
                                    <select class="form-control" id="tipo_documento" name="tipo_documento" type="text" required>
                                        <option value="">Seleccionar</option>
                                        <?php foreach ($tipo_documento as $parametro) { ?>
                                            <option value="<?php echo $parametro['id']; ?>"><?php echo $parametro['valor']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Número de Documento</label>
                                    <input class="form-control" id="numero_documento" name="numero_documento" type="text"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Dígito de Verificación</label>
                                    <input class="form-control" id="dv" name="dv" type="text" disabled="true"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Tipo de Cliente</label>
                                    <select class="form-control" id="tipo_cliente" name="tipo_cliente" type="text" required>
                                        <option value="">Seleccionar</option>
                                        <?php foreach ($tipo_Cliente as $tipocliente) { ?>
                                            <option value="<?php echo $tipocliente['id']; ?>"><?php echo $tipocliente['valor']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-6">
                                    <label>Primer Nombre</label>
                                    <input class="form-control" id="p_nombre" name="p_nombre" type="text"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-6">
                                    <label>Segundo Nombre</label>
                                    <input class="form-control" id="s_nombre" name="s_nombre" type="text"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-6">
                                    <label>Primer Apellido</label>
                                    <input class="form-control" id="p_apellido" name="p_apellido" type="text"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-6">
                                    <label>Segundo Apellido</label>
                                    <input class="form-control" id="s_apellido" name="s_apellido" type="text"></>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-12 col-sm-12">
                                    <label>Razón Social</label>
                                    <input class="form-control" id="razon_social" name="razon_social" type="text"></>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <label>Dirección</label>
                                    <input class="form-control" id="direccion" name="direccion" type="text"></>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <label>País</label>
                                    <select class="form-control" id="pais" name="pais" type="text" selected="selected" required>
                                        <option value="">Seleccionar</option>
                                        <?php foreach ($pais as $row) { ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-12 col-sm-6">
                                        <label>Departamento</label>
                                        <select class="form-control" id="departamento" name="departamento" type="text" required>
                                            <option value="">Seleccionar</option>

                                        </select>
                                    </div>
                                    <div class="col-12 col-sm-6">
                                        <label>Municipio</label>
                                        <select class="form-control" id="municipio" name="municipio" type="text" required>
                                            <option value="">Seleccionar</option>

                                        </select>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-6">
                                    <label>Correos Electrónico</label>
                                    <div class="input-group">
                                        <input class="form-control" disabled="true" id="email" name="email" type="email"></>
                                        <span class="input-group-btn">
                                            <button id="fijo" class="btn btn-success add_telephone" href="#" data-toggle="modal" data-target="#modal-telefono" data-placement="top" type="button">
                                                <span class=" fas fa-at"></span>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Teléfonos Fijo</label>
                                    <div class="input-group">
                                        <input class="form-control" disabled="true" id="fijo" name="fijo" type="text"></>
                                        <span class="input-group-btn">
                                            <button id="fijo" class="btn btn-success add_telephone" href="#" data-toggle="modal" data-target="#modal-telefono" data-placement="top" type="button">
                                                <span class=" fas fa-tty"></span>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-5ths col-lg-5ths col-xs-6 col-sm-3">
                                    <label>Teléfonos Celular</label>
                                    <div class="input-group">
                                        <input class="form-control" disabled="true" id="celular" name="celular" type="text"></>
                                        <span class="input-group-btn">
                                            <button id="fijo" class="btn btn-success add_telephone" href="#" data-toggle="modal" data-target="#modal-telefono" data-placement="top" type="button">
                                                <span class=" fas fa-mobile-alt"></span>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url(); ?>/clientes" class="btn btn-primary">Regresar</a>
                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>
            </form>
        </div>
</div>
</main>
<div class="modal fade" id="modal-telefono" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-Telephone">
        <div style="background: linear-gradient(90deg, #838da0, #b4c1d9);" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar Teléfonos/Email</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-sm-4">
                        <label>Teléfono</label>
                        <input class="form-control" id="telefono" name="telefono" type="text" required></>
                    </div>
                    <div class="col-6 col-sm-2">
                        <label>Extensión</label>
                        <input class="form-control" id="telefono" name="telefono" type="text" required></>
                    </div>
                    <div class="col-12 col-sm-4">
                        <label>Prioridad</label>
                        <select class="form-control" id="prioridad" name="prioridad" type="text" required>
                            <option value="">Seleccionar Prioridad</option>
                            <option value="1"> Principal</option>
                            <option value="2"> Secundario</option>
                        </select>
                    </div>
                    <div class="col-12 col-sm-2">
                        <label><br>&nbsp;</label>
                        <button id="agregar_dato" name="agregar_dato" class="btn btn-primary" type="button" onclick="agregarProducto(nombre.value, prioridad.value,'F')">
                            Agregar
                        </button>
                    </div>
                </div>
            </div>
            <div class="row">
                <table id="tablaItems" class="table table-bordered table-striped  tablaItems" width="100%" cellspacing="0">
                    <thead>
                        <tr style="color:#98040a;font-weight:300;text-align:center;font-size:14px;">
                            <th>Id</th>
                            <th>Dato</th>
                            <th>Prioridad</th>
                            <th>Tipo</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

</div>
</html>


<script>
    $(document).ready(function(){
        recargarDepartamentos();
        $('#pais').change(function(){
            recargarDepartamentos();
        });
    
        recargarMunicipios();
        $('#departamento').change(function(){
            recargarMunicipios();
        });       
    })
</script>

<script>
function recargarDepartamentos(){
    $.ajax({
        type:"POST",
        url:"<?php echo base_url(); ?>/clientes/getDepartamentos",
        data:"codpais=" + $('#pais').val(),
        success:function(r){
            $('#departamento').html(r);
        }
    });
};
</script>
<script>
function recargarMunicipios(){
    $.ajax({
        type:"POST",
        url:"<?php echo base_url(); ?>/clientes/getMunicipios",
        data:"coddepartamento=" + $('#departamento').val(),
        success:function(r){
            $('#municipio').html(r);
        }
    });
}
</script>