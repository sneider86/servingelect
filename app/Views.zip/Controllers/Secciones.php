<?php

namespace App\Controllers;


use App\Controllers\BaseController; /*la plantilla del controlador general de codeigniter */
use App\Models\ParametrosModel;
use App\Models\RolesModel; /* clase a la cual se esta apuntando con los modelos */
use App\Models\ModulosModel;
use App\Models\SeccionesModel;

class Secciones extends BaseController
{
    /*interactua el controlador con el modelo */
    protected $secciones, $roles, $modulos;
    protected $reglas;

    public function __construct()
    {
        $this->secciones = new ParametrosModel();
        $this->roles = new RolesModel();
        $this->modulos = new ModulosModel();
        $this->secciones = new SeccionesModel();

        helper(['form']);
        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ]
        ];
    }


    public function index($activo = 1) 
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();

        $secciones = $this->secciones->where('activo', $activo)->findAll(); 
        $data = ['titulo' => 'MANEJO DE SECCIONES', 'datos' => $secciones, 'roles' => $roles, 'modulos' => $modulos]; 
        /* mostramos la vista */
        echo view('header', $data);
        echo view('actividades/secciones', $data);
        echo view('footer');
    }

    public function eliminados_seccion($activo = 0) 
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();
        $secciones = $this->secciones->where('activo', $activo)->findAll(); 
        $data = ['titulo' => 'SECCIONES ELIMINADAS', 'datos' => $secciones, 'roles' => $roles, 'modulos' => $modulos]; 

        echo view('header', $data);
        echo view('actividades/eliminados_seccion', $data);
        echo view('footer');
    }

    public function nueva_seccion()
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();
        $data = ['titulo' => 'CREAR SECCIONES', 'roles' => $roles, 'modulos' => $modulos];
        echo view('header', $data);
        echo view('actividades/nueva_seccion', $data);
        echo view('footer');
    }

    public function inserta_seccion()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $session = session();
            $this->secciones->save([
                'codigo' => strtoupper($this->request->getPost('codigo')),
                'nombre' => strtoupper($this->request->getPost('nombre'))
            ]);

            /* save=metodo de guardar []=por ser arreglos y los campos a guardar, getPost por si se usa uno de los 2 lo valide */
            return redirect()->to(base_url() . '/secciones');
            /* dejamos la accion en el mismo formulario */
            /* return redirect()->to(base_url() . '/secciones'); redireccionamos el retorno despues de guardar a la pantalla de index o la principal de secciones */
        } else {
            $roles = $this->roles->where('activo', 1)->findAll();
            $where = " activo = 1 order by padre_id,orden";
            $modulos = $this->modulos->where($where)->findAll();
            $data = ['titulo' => 'CREAR SECCIONES', 'roles' => $roles, 'modulos' => $modulos, 'validaton' => $this->validator];
            echo view('header', $data);
            echo view('actividades/nueva_seccion', $data);
            echo view('footer');
        }
    }

    public function edita_seccion($id, $valid=Null)
    { 

            $seccion = $this->secciones->where('codigo', $id)->first(); 
            $roles = $this->roles->where('activo', 1)->findAll();
            $where = " activo = 1 order by padre_id,orden";
            $modulos = $this->modulos->where($where)->findAll();

                if ($valid !== null) {
                    $data = ['titulo' => 'EDITAR SECCION', 'datos' => $seccion, 'roles' => $roles, 'modulos' => $modulos,'validation' => $valid];
                } else {
                    $data = ['titulo' => 'EDITAR SECCION', 'datos' => $seccion, 'roles' => $roles, 'modulos' => $modulos];
                }
    
                echo view('header', $data);
                echo view('actividades/editar_seccion', $data);
                echo view('footer');


        
    }

    public function actualizar_seccion()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $this->secciones->update($this->request->getPost('id'), [
                'nombre' => $this->request->getPost('nombre')
            ]);
            return redirect()->to(base_url() . '/secciones');
        } else {
            return $this->edita_seccion($this->request->getPost('id'), $this->validator);
        }
    }

    public function elimina_seccion($id)
    {
        $this->secciones->update($id, ['activo' => 0]);
        return redirect()->to(base_url() . '/secciones');
    }
    public function activa_seccion($id)
    {
        $this->secciones->update($id, ['activo' => 1]);
        return redirect()->to(base_url() . '/secciones/eliminados_seccion');
    }
}
