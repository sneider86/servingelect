<?php

namespace App\Controllers;


use App\Controllers\BaseController; /*la plantilla del controlador general de codeigniter */
use App\Models\RolesModel; /* clase a la cual se esta apuntando con los modelos */
use App\Models\ModulosModel;
use App\Models\SeccionesModel;
use App\Models\DivisionesModel;

class Divisiones extends BaseController
{
    /*interactua el controlador con el modelo */
    protected $divisiones, $roles, $modulos, $secciones;
    protected $reglas;

    public function __construct()
    {
        $this->divisiones = new DivisionesModel();
        $this->roles = new RolesModel();
        $this->modulos = new ModulosModel();
        $this->secciones = new SeccionesModel();

        helper(['form']);
        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ]
        ];
    }

    public function index($activo = 1) 
    {
        $secciones = $this->secciones->where('activo', 1)->findAll();
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();        
        $datos = $this->divisiones->obtenerSeccion(1); 
        $divisiones = $this->divisiones->where('activo', $activo)->findAll(); 
        $data = ['titulo' => 'MANEJO DE DIVISIONES DE ACTIVIDADES', 'datos' => $divisiones, 'roles' => $roles, 'modulos' => $modulos, 'secciones' => $secciones, 'datos' => $datos]; 

        echo view('header', $data);
        echo view('actividades/divisiones', $data);
        echo view('footer');
    }

    public function eliminadas_divisiones($activo = 0) 
    {
        $secciones = $this->secciones->where('activo', 1)->findAll();
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();
        $datos = $this->divisiones->obtenerSeccion(0); 
        $divisiones = $this->divisiones->where('activo', $activo)->findAll(); 
        $data = ['titulo' => 'DIVISIONES DE ACTIVIDADES ELIMINADAS', 'datos' => $divisiones, 'roles' => $roles, 'modulos' => $modulos, 'secciones' => $secciones, 'datos' => $datos, 'datos' => $datos]; 

        /* mostramos la vista */
        echo view('header', $data);
        echo view('actividades/eliminadas_divisiones', $data);
        echo view('footer');
    }

    public function nueva_divison()
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";
        $modulos = $this->modulos->where($where)->findAll();

        $where = "activo=1 order by nombre";
        $secciones = $this->secciones->where($where)->findAll();        
        $data = ['titulo' => 'CREAR DIVISIONES DE ACTIVIDADES', 'roles' => $roles, 'modulos' => $modulos, 'secciones' => $secciones];
        echo view('header', $data);
        echo view('actividades/nueva_division', $data);
        echo view('footer');
    }

    public function inserta_division()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $session = session();
            $this->divisiones->save([
                'id_seccion' => strtoupper($this->request->getPost('id_seccion')),
                'codigo' => $this->request->getPost('codigo'),                
                'nombre' => $this->request->getPost('nombre')
            ]);

            return redirect()->to(base_url() . '/divisiones');

        } else {
            $roles = $this->roles->where('activo', 1)->findAll();
            $where = " activo = 1 order by padre_id,orden";
            $modulos = $this->modulos->where($where)->findAll();            
            $data = ['titulo' => 'CREAR DIVISIONES DE ACTIVIDADES','roles' => $roles, 'modulos' => $modulos,'validaton' => $this->validator]; 
            echo view('header', $data);
            echo view('actividades/nueva_division', $data);
            echo view('footer');
        }
    }

    public function editar_division($id, $valid=null)
    { {
            
            $roles = $this->roles->where('activo', 1)->findAll();
            $where = " activo = 1 order by padre_id,orden";
            $modulos = $this->modulos->where($where)->findAll();           
            $divisiones = $this->divisiones->where('codigo', $id)->first();
            $secciones = $this->secciones->where('activo', 1)->findAll();            
            if($valid !== null){
                $data = ['titulo' => 'EDITAR DIVISONES DE ACTIVIDADES', 'datos' => $divisiones,'roles' => $roles, 'modulos' => $modulos, 'secciones' => $secciones,'validation' => $valid];
            }else{
                $data = ['titulo' => 'EDITAR DIVISONES DE ACTIVIDADES', 'datos' => $divisiones,'roles' => $roles, 'modulos' => $modulos, 'secciones' => $secciones];
            }            
            echo view('header', $data);
            echo view('actividades/editar_division', $data);
            echo view('footer');
        }
    }
    public function actualizar_division()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $this->divisiones->update($this->request->getPost('id'), [
            'nombre' => $this->request->getPost('nombre')
        ]);
            return redirect()->to(base_url() . '/divisiones');
        } else {
            return $this->editar_division($this->request->getPost('id'),$this->validator);
        }
    }

    public function eliminar_division($codigo)
    {
        $this->divisiones->update($codigo, ['activo' => 0]);
        return redirect()->to(base_url() . '/divisiones');
    }
    public function activar_division($codigo)
    {
        $this->divisiones->update($codigo, ['activo' => 1]);
        return redirect()->to(base_url() . '/divisiones/eliminadas_divisiones');
    }
}
