<?php

namespace App\Controllers;


use App\Controllers\BaseController; /*la plantilla del controlador general de codeigniter */
use App\Models\TemporalTelefonosModel;
use App\Models\ProductosModel;

class TemporalTelefonos extends BaseController
{
    /*interactua el controlador con el modelo */
    protected $temporal_telefonos;
    protected $reglas;

    public function __construct()
    {
        $this->temporal_telefonos = new TemporalTelefonosModel();


    }

    public function insertar($nombre, $prioridad, $tipo)
    {

                $this->temporal_telefonos->save([
                    'nombre' => $temporal_telefonos['nombre'],
                    'prioridad' => $temporal_telefonos['prioridad'],
                    'tipo' => $tipo
                    ]);
          
       
        $res['datos'] = $this->cargaProducto($nombre);  //lo cargamos para que se ejecuta

        echo json_encode($res);
    }

    public function cargaProducto($id_compra)
    { 
        $resultado = $this->temporal_compra->porCompra($id_compra); //traemos los registros de la temporal
        $fila = '';
        $numFila = 0;
        foreach($resultado as $row){
            //se crea una tabla html, embebida en php
            $numFila++;
            $fila .= "<tr id='fila".$numFila."'>";
            $fila .= "<td>".$numFila."</td>";
            $fila .= "<td>".$row['codigo']."</td>";
            $fila .= "<td>".$row['nombre']."</td>";
            $fila .= "<td>".number_format($row['precio'],2,'.',',')."</td>";
            $fila .= "<td>".number_format($row['cantidad'],2,'.',',')."</td>";
            $fila .= "<td>".number_format($row['subtotal'],2,'.',',')."</td>";
            $fila .= "<td><a onclick=\"eliminarProducto(". $row['id_producto'].", '".$id_compra."')\" class='borrar'><span class='fas fa-fw fa-trash'></span></a></td>";
            $fila .= "</tr>";
        }
        return $fila;
    }

    public function totalProducto($id_compra)
    { 
        $resultado = $this->temporal_compra->porCompra($id_compra); //traemos los registros de la temporal
        $total = 0;
        
        foreach($resultado as $row){
            $total += $row['subtotal'];           
        }
        return $total;
    }

    public function eliminar($id_producto, $id_compra){
        $datosExiste = $this->temporal_compra->porIdProductoCompra($id_producto, $id_compra);
        if($datosExiste->cantidad>1){
            $cantidad = $datosExiste->cantidad - 1; //la hago igual a $datosExiste en su propiedad cantidad -1
            $subtotal = $cantidad * $datosExiste->precio;
            $this->temporal_compra->actualizarProductoCompra($id_producto, $id_compra, $cantidad, $subtotal);            
        } else{
            $this->temporal_compra->eliminarProductoCompra($id_producto, $id_compra);
        }
        $res['datos'] = $this->cargaProducto($id_compra);  //lo cargamos para que se ejecuta
        $res['total'] = number_format($this->totalProducto($id_compra), 2 ,'.',','); 
        $res['error'] = '';
        echo json_encode($res);
    }

}
