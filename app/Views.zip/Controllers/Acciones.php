<?php
namespace App\Controllers;



use App\Controllers\BaseController; /*la plantilla del controlador general de codeigniter */
use App\Models\RolesModel;
use App\Models\ModulosModel;
use App\Models\AccionesModel;

class Acciones extends BaseController
{
    /*interactua el controlador con el modelo */
    protected $roles,  $acciones;
    protected $modulos;
    protected $reglas;

    public function __construct()
    {
        $this->roles = new RolesModel();
        $this->modulos = new ModulosModel();
        $this->acciones = new AccionesModel();

        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ],
            'id_modulo' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ]
        ];
    }

    /*Interactuamos con la vista con la funcion index */
    public function index($activo = 1) /* 2 vistas la de los activos y la de los inactivos y por defecto se cargara la vista de los activos */
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $acciones = $this->acciones->where('activo', $activo)->findAll();
        $data = ['titulo' => 'MANEJO DE ACCIONES', 'datos' =>  $acciones,'roles' => $roles, 'modulos' => $modulos]; 
        /* mostramos la vista */
        echo view('header', $data);
        echo view('acciones/acciones', $data);
        echo view('footer');
    }

    public function eliminados($activo = 0)
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $acciones = $this->acciones->where('activo', $activo)->findAll();
        $data = ['titulo' => 'ACCIONES ELIMINADAS', 'datos' => $acciones, 'modulos' => $modulos, 'roles' => $roles]; 
        echo view('header', $data);
        echo view('acciones/eliminados', $data);
        echo view('footer');
    }

    public function nuevo()
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'CREAR ACCIONES', 'modulos' => $modulos, 'roles' => $roles];

        echo view('header', $data);
        echo view('acciones/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'CREAR ACCIONES', 'modulos' => $modulos];
        $session = session();  
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {

            $this->acciones->save([
                'nombre' => $this->request->getPost('nombre'),
                'id_modulo' => $this->request->getPost('id_modulo'),
                'usuario_crea' => $session->id_usuario
            ]);
            return redirect()->to(base_url() . '/acciones');
        } else {
            $data = ['titulo' => 'CREAR MODULOS','roles' => $roles,'modulos' => $modulos,'validaton' => $this->validator]; 
            echo view('header', $data);
            echo view('acciones/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id, $valid=null)
    { {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
            $acciones = $this->acciones->where('id',$id)->first();
            if($valid !== null){
                $data = ['titulo' => 'EDITAR ACCIONES', 'datos' => $acciones, 'modulos' => $modulos,'roles' => $roles,'validation' => $valid];

            }else{
                $data = ['titulo' => 'EDITAR ACCIONES', 'datos' => $acciones, 'modulos' => $modulos,'roles' => $roles];
            }
            
            echo view('header', $data);
            echo view('acciones/editar', $data);
            echo view('footer');
        }
    }
    public function actualizar()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $this->acciones->update($this->request->getPost('id'), [
                'nombre' => $this->request->getPost('nombre'),
                'id_modulo' => $this->request->getPost('id_modulo')
        ]);
            return redirect()->to(base_url() . '/acciones');
        } else {
            return $this->editar($this->request->getPost('id'),$this->validator);
        }
    }

    public function eliminar($id)
    {
        $this->acciones->update($id, ['activo' => 0]);
        //$modulos = $this->modulos->where('activo', 1)->findAll();
        return redirect()->to(base_url() . '/acciones');
    }
    public function activar($id)
    {
        $this->acciones->update($id, ['activo' => 1]);
        //$modulos = $this->modulos->where('activo', 1)->findAll();
        return redirect()->to(base_url() . '/acciones/eliminados');
    }
}
