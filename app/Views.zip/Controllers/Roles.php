<?php

namespace App\Controllers;


use App\Controllers\BaseController; /*la plantilla del controlador general de codeigniter */
use App\Models\RolesModel;
use App\Models\ModulosModel;

class Roles extends BaseController
{
    /*interactua el controlador con el modelo */
    protected $roles, $modulos;
    protected $reglas;

    public function __construct()
    {
        $this->roles = new RolesModel();
        $this->modulos = new ModulosModel();
        helper(['form']);

        $this->reglas = [
            'nombre' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ],
            'descripcion' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El Campo {field} es Obligatorio.'
                ]
            ]
        ];
    }

    /*Interactuamos con la vista con la funcion index */
    public function index($activo = 1) /* 2 vistas la de los activos y la de los inactivos y por defecto se cargara la vista de los activos */
    {
        $roles = $this->roles->where('activo', $activo)->findAll(); /*le asigno a la variable la consulta dada */
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'MANEJO DE ROLES', 'datos' => $roles, 'modulos' => $modulos, 'roles' => $roles]; /*creamos el arreglo $data y se lo enviamos a la vista con los campos definidos, datos tendra toda la informacion resultante de la consulta */

        /* mostramos la vista */
        echo view('header', $data);
        echo view('roles/roles', $data);
        echo view('footer');
    }

    public function nuevo()
    {
        $roles = $this->roles->where('activo', 1)->findAll();
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'CREAR ROL', 'modulos' => $modulos, 'roles' => $roles];

        echo view('header', $data);
        echo view('roles/nuevo', $data);
        echo view('footer');
    }
    public function eliminados($activo = 0) /*vista de los inactivos y por defecto se cargaran */
    {
        $roles = $this->roles->where('activo', $activo)->findAll(); /*le asigno a la variable la consulta dada */
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'ROLES ELIMINADOS', 'datos' => $roles, 'modulos' => $modulos]; /*creamos el arreglo $data y se lo enviamos a la vista con los campos definidos, datos tendra toda la informacion resultante de la consulta */

        /* mostramos la vista */
        echo view('header', $data);
        echo view('roles/eliminados', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $roles = $this->roles->where('activo', 1)->findAll(); /*le asigno a la variable la consulta dada */
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        $data = ['titulo' => 'MANEJO DE ROLES', 'datos' => $roles, 'modulos' => $modulos, 'roles' => $roles]; 
        //$data = ['titulo' => 'CREAR ROL', 'modulos' => $modulos];

        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {

            $this->roles->save([
                'nombre' => $this->request->getPost('nombre'),
                'descripcion' => $this->request->getPost('descripcion'),
                'padre' => $this->request->getPost('padre')
            ]);

            /* save=metodo de guardar []=por ser arreglos y los campos a guardar, getPost por si se usa uno de los 2 lo valide */
            return redirect()->to(base_url() . '/roles');
            /* dejamos la accion en el mismo formulario */
            /* return redirect()->to(base_url() . '/roles'); redireccionamos el retorno despues de guardar a la pantalla de index o la principal de roles */
        } else {
            $data = ['titulo' => 'CREAR ROL','modulos' => $modulos,'validaton' => $this->validator]; 
            echo view('header', $data);
            echo view('roles/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id, $valid=null)
    { {
            $rol = $this->roles->where('id', $id)->first(); /*consulta de registro a editar */
            $where = " activo = 1 order by padre_id,orden";        
            $modulos = $this->modulos->where($where)->findAll(); 
            $roles = $this->roles->where('activo',1)->findAll();

            if($valid !== null){
                $data = ['titulo' => 'EDITAR ROL', 'datos' => $rol, 'modulos' => $modulos,'roles' => $roles,'validation' => $valid];

            }else{
                $data = ['titulo' => 'EDITAR ROL', 'datos' => $rol, 'modulos' => $modulos,'roles' => $roles];
            }
            
            echo view('header', $data);
            echo view('roles/editar', $data);
            echo view('footer');
            
        }
    }
    public function actualizar()
    {
        if ($this->request->getMethod() == "post" && $this->validate($this->reglas)) {
            $this->roles->update($this->request->getPost('id'), [
            'nombre' => $this->request->getPost('nombre'),
            'descripcion'  => $this->request->getPost('descripcion'),
            'padre'  => $this->request->getPost('padre')
        ]);
            return redirect()->to(base_url() . '/roles');
        } else {
            return $this->editar($this->request->getPost('id'),$this->validator);
        }
    }

    public function eliminar($id)
    {
        $this->roles->update($id, ['activo' => 0]);
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        return redirect()->to(base_url() . '/roles');
    }
    public function activar($id)
    {
        $this->roles->update($id, ['activo' => 1]);
        $where = " activo = 1 order by padre_id,orden";        
        $modulos = $this->modulos->where($where)->findAll(); 
        return redirect()->to(base_url() . '/roles/eliminados');
    }
}
